<?php
/**
 * Example footer include
 *
 * This file shows you how to use the include hooks. However I recommend to
 * create your own complete new template instead. 
 */
 ?>
<div class="footer">
<b class="rtop"><b class="r1"></b><b class="r2"></b><b class="r3"></b><b class="r4"></b></b>
    <div class="footnotes">
          <?echo $conf['tpl_mmClean']['footer']; ?>
    </div>
<b class="rbottom"><b class="r4"></b><b class="r3"></b><b class="r2"></b><b class="r1"></b></b>
</div>

